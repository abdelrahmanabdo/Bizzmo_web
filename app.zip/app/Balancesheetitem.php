<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Balancesheetitem extends Model
{
	protected $guarded = array();
	
}
