<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Companyrelationtype extends Model
{
    public $table = 'company_relation_types';
}
