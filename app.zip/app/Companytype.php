<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Companytype extends Model
{
    const BUYER_TYPE = 1;
    const SUPPLIER_TYPE = 2;
    const BOTH_TYPE = 3;
}
