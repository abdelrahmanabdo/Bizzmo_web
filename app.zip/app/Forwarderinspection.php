<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Forwarderinspection extends Model
{
    //
}
