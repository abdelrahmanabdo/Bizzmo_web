<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Forwarderservices extends Model
{
    //
}
