<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Freightexpense extends Model
{
    
}
