<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

use Auth;
use DB;
use Input;
use View;

use App\Repositories\ChatRepository;

use App\Chat;
use App\Message;
use App\User;

class chatcontroller extends Controller
{
	public function index(Request $request, $id = '')
    {
		$chattitle = '';
		if ($id != '') {
			DB::table('chat_user')->where('chat_id', $id)->where('user_id', Auth::user()->id)->update(['unread' => 0]);
			$chattitle = "Chat: " . Chat::find($id)->title;
		}
		return View('chats.search')
			->with('title', $chattitle)
			->with('id', $id);
    }
	
	public function create()
    {
		return View('chats.manage')
			->with('title', "Create Chat");
    }
	
	public function newchat(Request $request)
	{
		$data = $request->input();
		$chat = ChatRepository::create($data);
		return redirect('/chat/' . $chat->id);
	}
	
	public function userchat()
    {
		$chats = Chat::with(['users' => function ($query) {
			$query->where('user_id', Auth::user()->id);
			}
		])->whereHas('users', function ($query) {
			$query->where('user_id', Auth::user()->id);
		})->get();
		
		return $chats;
    }

// Allows us to post new message
	public function save(Request $request)
	{
		$message = new Message();
		$content = request('message');
		$message->content = $content;
		$message->chat_id = $request->route('id');
		$message->user_id = Auth::user()->id;
		$message->sendername = Auth::user()->name;
		$message->save();
		DB::table('chat_user')->where('chat_id', $request->route('id'))->where('user_id', '!=', Auth::user()->id)->update(['unread' => DB::raw('unread + 1')]);
		
		$message = Message::find($message->id);
		
		//\Log::warning('broad: ' . $message);
		
		broadcast(new \App\Events\MessageSent($message));
		return $message;
	}
	
	public function getAll(Request $request)
	{
		$messages = Message::select('content', 'user_id', 'chat_id')->where('chat_id', $request->route('id'))->get();
		

		$messages = Message::selectRaw('messages.content, messages.user_id, messages.chat_id, users.name as sendername')
		->join('users', 'messages.user_id', 'users.id')
		->where('chat_id', $request->route('id'))->get();


		return $messages;
	}	
	
	public function dataAjax(Request $request)
	{
		$data = [];
		$search = $request->q;
		$query = User::select("users.id", "users.name")
			->distinct()
			->join('role_user', 'users.id', '=', 'role_user.user_id')
			->join('roles', 'roles.id', '=', 'role_user.role_id')
			->where('users.name', 'LIKE', "%$search%")
			->where('users.active', 1)
			->where('users.id', '<>', Auth::user()->id)
			->where('roles.company_id', '<>', 0)
			->orderBy('name');
		if ($search == '') {
			$query = $query->take(5);
		}
		return response()->json($query->get());
	}
	
	public function members(Request $request)
	{
		$list = rtrim($request->memberlist, ',');
		$userarr = explode(',', $list);
		$count = count($userarr);
		$chats = Chat::with('users')->whereHas('users', function ($query) use($userarr) {
			$query->whereIn('user_id', $userarr);
		})->get();
		//return $chats;
		foreach ($chats as $chat) {
			$allusersfound = true;
			foreach ($userarr as $user) {
				if (!in_array($user, $chat->users->pluck('id')->all())) {
					$allusersfound = false;
				}
			}
			if ($allusersfound && $chat->users->count() == $count) {
				return $chat->title;
			}
		}
		return '';
		die;
		
		$list = rtrim($request->memberlist, ',');
		$count = count(explode(',', $list));
		$chats = Chat::whereHas('users', function ($query) use($list) {
			$query->whereIn('user_id', explode(',', $list));
		})->get();
		return response()->json('');
		foreach ($chats as $chat) {
			if ($chat->users->count == $count) {
				return json($chat->title);
			}
		}
		return response()->json('');
	}
	
	public function resetcount(Request $request)
	{
		DB::table('chat_user')->where('chat_id', $request->route('id'))->where('user_id', request('userid'))->update(['unread' => 0]);
	}
}
