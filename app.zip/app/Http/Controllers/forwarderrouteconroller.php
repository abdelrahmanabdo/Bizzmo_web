<?php

namespace App\Http\Controllers;

use App\Companyforwarderroute;
use App\Forwarderroute;
use Auth;
use DB;
use Illuminate\Http\Request;
use Input;

class forwarderrouteconroller extends Controller
{
    public function view(Request $request, $id)
    {
        $route = Forwarderroute::where('company_id', $id)->first();
        return view('forwarderroutes.manage')->with('title', 'View Route')
            ->with('Forwarderroutes', $route);
    }
    public function template(Request $request, $id)
    {
        $templates = Companyforwarderroute::where('company_id', $id)->get();
        return view('forwarderroutes.template')
        ->with('company_id', $id)
        ->with('templates',$templates);
    }
    public function manage(Request $request, $id)
    {
        // $companyRoute = Companyforwarderroute::where('company_id', $id)->get();
        // $route = Forwarderroute::where('company_id', $id)->first();
        return view('forwarderroutes.manage')->with('title', 'View Route')
            ->with('company_id', $id);
            // ->with('Forwarderroutes', $route)
            // ->with('CompanyRoute', $companyRoute);
    }
    public function edit(Request $request, $id)
    {
        $companyRoute = Companyforwarderroute::where('id', $id)->first();
        $route = Forwarderroute::where('template_id', $id)->first();

        return view('forwarderroutes.manage')
        ->with('ispection_id', $id)
        ->with('companyRoute', $companyRoute)
        ->with('company_id', $companyRoute->company_id)
        ->with('Forwarderroutes', $route);
    }
    public function save(Request $request, $id)
    {
        $hasCompany = Auth::user()->companies->count();
        if ($hasCompany && !$id) {
            abort(404);
        }
        if (Input::has('route_id')) {
            //$Inspection = Forwarderinspection::where('id', $id)->first();
            DB::table('forwarderroutes')->where('template_id', $id)->delete();
            $CompanyRoute = Companyforwarderroute::where('id', $id)->first();
        }
        if (!isset($CompanyRoute)) {
            $CompanyRoute = new Companyforwarderroute;
        }
        $CompanyRoute->company_id = Input::get('company_id');
        $CompanyRoute->name = Input::get('templatename');
        $CompanyRoute->created_by = Auth::user()->id;
        $CompanyRoute->updated_by = Auth::user()->id;
        $CompanyRoute->save();

        $route = new Forwarderroute;
        
        $route->start = Input::get('routestart');
        $route->end = Input::get('routeend');
        $route->template_id = $CompanyRoute->id;
        $route->created_by = Auth::user()->id;
        $route->updated_by = Auth::user()->id;
        $route->save();
        return redirect('/forwarder/route/template/'.Input::get('company_id'));
        // return view('forwarderroutes.manage')->with('title', 'View Route')
        //     ->with('company_id', $id)
        //     ->with('Forwarderroutes', $route);
    }
}
