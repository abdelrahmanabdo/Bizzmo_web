<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Securitytype extends Model
{
    const SECURITY_CHEQUE = 4;
	const SECURITY_CHQAUTH = 8;
}
