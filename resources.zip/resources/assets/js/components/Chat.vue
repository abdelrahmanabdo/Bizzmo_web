<template>
    <div class="col-md-6">
        <div v-for="message in messages">
			<span v-if="message.chat_id == chatid"  v-bind:class="(message.user_id == userid)?'alert-success':'alert-info'">{{ message.sendername }} : {{ message.content }}</span>
		</div>
        <input v-model="text" class="form-control">
        <button @click="postMessage" :disabled="!contentExists" class="btn btn-success">send</button>
    </div>
</template>

<script>
    export default {
		props: {
		  chatid: String,
		  userid: String
		},
        data() {
            return {
                text: '',
                messages: []
            }
        },
        computed: {
            contentExists() {
                return this.text.length > 0;
            }
        },
        methods: {
            postMessage() {
                axios.post('/chat/post/' + this.chatid, {message: this.text}).then(({data}) => {
					//console.log('post:' + data);
                    this.messages.push(data);
                    this.text = '';
                });
            }
        },
        created() {
			axios.get('/chat/getAll/' + this.chatid).then(({data}) => {
				this.messages = data;
			});
			// Registered client on public channel to listen to MessageSent event
			Echo.channel('chat').listen('MessageSent', ({message}) => {
				if (message.chat_id == this.chatid) {
					//console.log('listen');
					axios.post('/chat/reset/' + this.chatid, {userid: this.userid});
					
					
					
				}				
				//console.log(message);
				this.messages.push(message);
			});
		}
    }
</script>