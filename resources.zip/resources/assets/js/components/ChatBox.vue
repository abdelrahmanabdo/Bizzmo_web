<template>
    <div class="col-md-6">
        <p v-for="message in messages">{{ message }}</p>
        <input v-model="text" class="form-control">
        <button @click="postMessage" :disabled="!contentExists" class="btn btn-success">submit</button>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                text: '',
                messages: []
            }
        },
        computed: {
            contentExists() {
                return this.text.length > 0;
            }
        },
        methods: {
            postMessage() {
                axios.post('/message/post', {message: this.text}).then(({data}) => {
                    this.messages.push(data);
                    this.text = '';
                });
            }
        },
        created() {
			axios.get('/message/getAll').then(({data}) => {
				this.messages = data;
			});
			// Registered client on public channel to listen to MessageSent event
			Echo.channel('public').listen('MessageSent', ({message}) => {
				this.messages.push(message);
			});
		}
    }
</script>