<template>
	<ul class="sidebar-list">
		<li v-for="chat in chats" v-bind:class="(chat.id != activechat)?'':'bm-active'">
			<a v-if="chat.id != activechat" :href="'/chat/' + chat.id" class="bm-vr-nav-link">{{ chat.title }} - {{ chat.users[0].pivot.unread }}</a>
			<a v-if="chat.id == activechat" :href="'/chat/' + chat.id" class="bm-vr-nav-link">{{ chat.title }}</a>			
		</li>
	</ul>
</template>

<script>
    export default {
		props: {
		  userid: String,
		  activechat: String
		},
        data() {
            return {
                chats: []
            }
        },
        methods: {
            
        },
        created() {
			axios.get('/chat/userchat').then(({data}) => {
				this.chats = data;
			});
			// Registered client on public channel to listen to MessageSent event
			Echo.channel('chat').listen('MessageSent', ({message}) => {
				//this.messages.push(message);
				
				for(let i = 0; i < this.chats.length; i++){
					if (message.chat_id == this.chats[i].id) {
						this.chats[i].users[0].pivot.unread = parseInt(this.chats[i].users[0].pivot.unread) + 1;
					}
				}
					
				
			});
		}
    }
</script>