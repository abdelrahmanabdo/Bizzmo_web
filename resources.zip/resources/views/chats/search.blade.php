@extends('layouts.app', ['hideRightMenuAndExtend' => true])
@section('title')
	@if (isset($title))
	{{ $title }}
	@endif
@stop
@section('content')	
	
	<div class="row bm-pg-header" style="position : relative">	<!-- row 1 -->
		<div style="position : absolute ; left : 0">
			<h2 class="bm-title">{{ $title }}</h2>
		</div>
		<div style="position : absolute ; right : 5">
				<a href="/chat/create" class="btn btn-info bm-btn" id="lnksubmit">
					<span title="New Chat">Create A New Chat</span>
				</a>
		</div>
	</div>				<!-- end row 1 -->
	<div class="row">	<!-- row 1 -->
		<div class="col-md-8"> <!-- Column 2 -->
			@if ($id)
				<chat chatid="{{ $id }}" userid="{{ Auth::user()->id }}"></chat>
			@endif
		</div>
	</div>				<!-- end row 1 -->

@stop	
@push('scripts')	
	
@endpush