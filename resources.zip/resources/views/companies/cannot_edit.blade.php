@extends('layouts.app')
@section('content')
<div>
	<div class="row">
		<div class="col-md-12" style="margin-bottom: 20px">
			<h3 class="bm-title">Edit Company</h3>
		</div>
		<div class="col-md-12" style="margin-bottom: 20px; padding: 10px 30px">
			<p class="red"><strong>You can not edit company</strong></p>
			<p>If you want to change company data, please sent an email to <a href="mailto:bizzmo@bizzmo.com" target="_top"><strong>bizzmo@bizzmo.com</strong></a></p>
	</div>
</div>
@stop