@extends('layouts.app')
@section('title')
	@if (isset($title))
	{{ $title }}
	@endif
@stop
@section('styles')
	<style>
		.po-history-table th, .po-history-table td {
			font-size: 11px;
		}
	</style>
@stop
@section('content')	
<div class="row bm-pg-header">
		<h2 class="bm-title">Routes</h2>
	</div>
	{{ Form::open(array('id' => 'frmManage', 'class' => '')) }}
	<div>
		
		@if (!isset($mode))
		<div class="form-group">
            <label>Route Name: </label>
            @if (isset($companyRoute))
                <input id="templatename" name="templatename" class="form-control" placeholder="Route Name" value="{{$companyRoute->name}}" />
				{{ Form::hidden('route_id', $companyRoute->id, array('route_id' => 'route_id', 'class' => 'form-control')) }}
            @else
                <input id="templatename" name="templatename" class="form-control" placeholder="Route Name" />
            @endif
        </div>
			{{ Form::open(array('id' => 'frmManage', 'class' => 'form-horizontal co-form', 'files' => true)) }}
			{{ Form::hidden('id', $company_id, array('id' => 'id', 'class' => 'form-control')) }}
			
			@if (isset($Forwarderroutes))
				{{ Form::text('routestart', $Forwarderroutes->start, array('id' => 'routestart', 'class' => 'form-control', 'placeholder'=>'Start')) }}
				{{ Form::text('routeend', $Forwarderroutes->end, array('id' => 'routeend', 'class' => 'form-control', 'placeholder'=>'End')) }}
			@else
				{{ Form::text('routestart', Input::old('routestart'), array('id' => 'routestart', 'class' => 'form-control', 'placeholder'=>'Start')) }}
				{{ Form::text('routeend', Input::old('routeend'), array('id' => 'routeend', 'class' => 'form-control', 'placeholder'=>'End')) }}
			@endif
			{{ Form::submit('Save', array('id' => 'submit', 'class' =>'btn btn-default prev-step bm-btn')) }}
			{{ Form::close() }}
		@else
			@if (isset($Forwarderroutes))
				{{$Forwarderroutes->start}}
				{{$Forwarderroutes->end}}
			@endif
		@endif
		{{ Form::hidden('company_id', $company_id, array('company_id' => 'company_id', 'class' => 'form-control')) }}
	</div>
@stop	
@push('scripts')	
	
@endpush