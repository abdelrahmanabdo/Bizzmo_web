<footer class="guest-pg-footer col-sm-12">
    <div class="footer-section flex-container-col">
        <div class="flex-container-col">
            <img class="footer-section-logo" src="{{ asset('images/footer-logo.png') }}" alt="bizzmo logo">
            <ul class="col-md-offset-0 col-md-12 col-sm-offset-3 col-sm-6 footer-section-links">
                <li class="col-md-6 col-sm-12"><a href="/how-it-works">How it works</a></li>
                <li class="col-md-6 col-sm-12"><a href="/support">Support</a></li>
                <li class="col-md-6 col-sm-12"><a href="#!">About</a></li>
                <li class="col-md-6 col-sm-12"><a href="#!">Terms and Conditions</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-section">
        <div class="flex-container-col footer-section-right">
            <a class="guest-pg-default-btn" href="/register">Register Now</a>
        </div>
    </div>
</footer>