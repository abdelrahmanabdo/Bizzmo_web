<div class="profile-brands-container col-md-12 col-xs-12">
    <div class="brands col-md-12 col-xs-12">
        <div class="brands-title">Brand interests : </div>
        <div class="brands-content " >
        <img src="{{asset('images/ibm-logo.jpg')}}" alt="" width="80" height="80">
        <img src="{{asset('images/ibm-logo.jpg')}}" alt="" width="80" height="80">
        <img src="{{asset('images/ibm-logo.jpg')}}" alt="" width="80" height="80">
        <img src="{{asset('images/ibm-logo.jpg')}}" alt="" width="80" height="80">
        <img src="{{asset('images/ibm-logo.jpg')}}" alt="" width="80" height="80">
        <img src="{{asset('images/ibm-logo.jpg')}}" alt="" width="80" height="80">
        </div>
    </div>
</div>