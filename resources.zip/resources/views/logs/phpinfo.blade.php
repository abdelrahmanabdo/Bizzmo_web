@extends('layouts.app')
@section('title')
	@if (isset($title))
		{{ $title }}		
	@endif
@stop 
@section('content')
	{{ phpinfo() }}
@stop