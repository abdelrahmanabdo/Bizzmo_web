@extends('layouts.app')
@section('title')
@if (isset($title))
{{ $title }}
@endif
@stop
@section('content')
<div class="page-layout">
    <div class="page-head col-md-12 col-sm-12 row">
        <div class="head-text col-md-10">
            <span class="breadcrumb">
                Product Categories > Electronic
            </span>
            <h4 class="product-name">
                {{$product->name}}
            </h4>
        </div>
        <div class="head-edit-button col-md-2">
            <div class="edit-button">
                <a class="editProductButton btn " href="{{route('showEditProduct',$product->id)}}">
                    <img src="{{asset('images/edit-icon.svg')}}" /> Edit Product</a>
            </div>
        </div>
    </div>
    <div class="product-basic-information col-md-12 col-sm-12 row ">
        <div class="images-slider col-md-12">
        @if($product->images->count() > 0)
            <div class="current-image col-md-12 ">
                <img src="{{asset($product->images[0]->image)}}" />
            </div>
            <div class="other-images col-md-12">
                @foreach ($product->images as $image)
                <div class="image">
                    <img src="{{asset($image->image)}}" />
                </div>
                @endforeach
            </div>
        @endif
        </div>
        <div class="product-info col-md-12">
            <div class="nameContainer">
                {{$product->name}}
            </div>
            <div class="descriptionContainer">
                <div class="title">
                    Description :
                </div>
                <div class="description">
                    <p>{{$product->description}} </p>
                    <p class="read-more"><a href="#Description" class="button">See More</a></p>
                </div>

            </div>
            <div class="priceContainer">
                <div class="offer-price">{{$product->offer ? $product->offer.' '.$product->getCurrency(): ''}}</div>
                <div class="original-price">{{$product->price . ' '.$product->getCurrency()}}</div>
            </div>
        </div>
    </div>
    <div class="product-specifications  col-md-12 col-sm-12 row ">
        <div class="tab-header">
            <a class="active Description" onclick="toggleTab('Description')">Description</a>
            <a class="Specifications" onclick="toggleTab('Specifications')">Specifications</a>
        </div>
        <div class="specifications-content">
            <div id="Description" class="tabs">
                <p> {{$product->description}}</p>
            </div>
            <div id="Specifications" class="tabs" style="display:none">
                @forelse($product->attributes as $attribute)
                @if($attribute->pivot->value !== null)
                <div class="specification col-md-6">
                    <div class="specification-name col-md-6">{{str_replace('_' , ' ',$attribute->attribute)}}</div>
                    <div class="specification-value col-md-6">{{$attribute->pivot->value}}</div>
                </div>
                @endif
                @empty
                <div class="no-specifications">
                    <h4> No Specifications</h4>
                </div>

                @endforelse


            </div>
        </div>
    </div>
    @if(isset($similarProducts) && count($similarProducts) > 0)
    <div class="similar-products  col-md-12 col-sm-12 row ">
        <div class="title">
            Similar Products
        </div>
        <div class="products owl-carousel col-md-12 ">
            @foreach ($similarProducts as $product )
            <div class="productBox item ">
                <div class="productImage">
                    <img src="{{count($product->images) > 0 ? asset($product->images[0]->image ): ''}}" />
                </div>
                <div class="productDetails">
                    <div class="productName">
                        <a href="{{route('displayProductDetails',$product->id)}}">{{$product->name}}
                        </a>
                    </div>
                    <div class="productPriceContainer">
                        <div class="productPrice" @if($product->offer != Null) style="text-decoration : line-through;
                            color:
                            #bdbdbd; font-size:14px; font-weight:400 "
                            @endif>
                            {{$product->price . ' '. $product->getCurrency()}}
                        </div>
                        @if($product->offer != Null)
                        <div class="productPriceOffer">
                             {{$product->offer . ' '. $product->getCurrency()}}
                        </div>
                        @endif
                    </div>
                    <div class="addToCart">
                        <img class="addToCartIcon" src="{{asset('images/cart.svg')}}">
                        <h4> Add To Cart </h4>
                    </div>
                </div>
            </div>
            @endforeach

        </div>
    </div>
    @endif
</div>

@push('scripts')
<script>
    $(document).ready(function () {
        $('.owl-carousel').owlCarousel({
            margin: 1,
            padding: 2,
            navigation: false,

        });

        $('.product-basic-information .images-slider .other-images img').on('click', function () {
            var imageURL = $(this).attr('src');
            $('.product-basic-information .images-slider .current-image img').attr('src', imageURL);
        });
    });

    function toggleTab(tab) {
        var i;
        var x = document.getElementsByClassName("tabs");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
            x[i].classList.remove('active');
        }
        document.getElementById(tab).style.display = "block";
    }
</script>
@endpush
@endsection

<style>
    .page-layout {
        padding: 5px;
        height: 100%;
        width: 100%;
    }

    .page-head {
        height: 5%;
        height: fit-content;
        margin: 10px;
        display: flex;
        padding: 0 !important;
    }

    .head-text {
        display: block;
        float: right;
        padding-left: 0 !important;
    }

    .head-text .breadcrumb {
        padding-left: 0 !important;
        color: #9e9e9e;
    }

    .head-text .product-name {
        color: #1a425e;
        font-size: 18px;
        font-weight: 600;
    }

    .head-edit-button {
        float: right;
        padding: 0 !important;
    }

    .edit-button {
        text-align: center;
        height: 40px;
        border: 2px solid #41b4be;
        border-radius: 4px;
    }

    .edit-button a {
        color: #41b4be;
        font-size: 14px;
        font-weight: 600;
    }

    .edit-button a:hover {
        color: #41b4be;
    }


    .product-basic-information {
        background-color: #fff;
        min-height: 400px !important;
        height: fit-content;
        margin: 10px;
        display: flex;
        padding: 10px;
        box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.15);
    }

    .product-basic-information .images-slider {
        width: 50%;
    }

    .product-basic-information .images-slider .current-image {
        width: 100%;
        height: 65%;
        border: solid 1px rgba(0, 0, 0, 0.1);
        border-radius: 4px;
    }

    .product-basic-information .images-slider .current-image img {
        width: 100%;
        height: 100%;

    }

    .product-basic-information .images-slider .other-images {
        width: 100%;
        height: 30%;
        display: flex;
        margin-bottom: 10px !important;
        padding-left: 0 !important;
        padding-right: 0 !important;

    }

    .product-basic-information .images-slider .other-images .image {
        width: 20%;
        height: 100%;
        padding: 4px;
        border-radius: 4px;
        border: solid 1px rgba(0, 0, 0, 0.1);
        margin-top: 10px;
        margin-right: 5px;
        cursor: pointer;

    }

    .product-basic-information .images-slider .other-images img {
        width: 100%;
        height: 100%;
    }

    .product-basic-information .product-info {
        width: 50%;
        display: block;
    }

    .product-basic-information .product-info .nameContainer {
        height: fit-content;
        padding: 4px;
        font-size: 24px;
        font-weight: 600;
        color: #212121;
        word-wrap: break-word;
    }

    .product-basic-information .product-info .descriptionContainer {
        height: 60%;
        padding: 6px;
        min-height: 200px;

    }

    .product-basic-information .product-info .descriptionContainer .title {
        font-size: 16px;
        font-weight: 500;
        color: #424242;
    }

    .product-basic-information .product-info .descriptionContainer .description {}

    .product-basic-information .product-info .descriptionContainer .description p {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        margin: 0;
    }

    .product-basic-information .product-info .priceContainer {
        height: 20%;
        padding: 6px;
    }

    .product-basic-information .product-info .priceContainer .original-price {
        font-size: 24px;
        font-weight: 600;
        font-stretch: normal;
        font-style: normal;
        line-height: 1.33;
        letter-spacing: 0.29px;
        color: #1a425e;
    }

    .product-basic-information .product-info .priceContainer .offer-price {
        font-size: 14px;
        font-weight: normal;
        font-stretch: normal;
        font-style: normal;
        line-height: normal;
        letter-spacing: 0.17px;
        color: #bdbdbd;
        text-decoration: line-through;
    }


    .product-specifications {
        background-color: #fff;
        margin: 10px;
        min-height: 40%;
        height: fit-content;
        padding: 0 !important;
        box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.15);
    }

    .product-specifications .tab-header {
        width: 100%;
        display: flex;
        border-bottom: 1px solid #eeeeee;
        padding: 6px;
    }

    .product-specifications .tab-header a {
        padding: 10px;
        color: #000000;
        font-weight: 600;
        font-stretch: normal;
        font-style: normal;
        line-height: 1.38;
        font-size: 16px;
        letter-spacing: 0.19px;
        cursor: pointer;

        text-decoration: none;
    }

    .product-specifications .tab-header .active {
        padding-bottom: 0;
        border-bottom: 2px solid #41b4be;
    }

    .product-specifications .specifications-content {
        width: 100%;
        height: fit-content;
        padding: 16px;

    }

    .product-specifications .specifications-content #Description {
        margin: 15px;
    }



    .product-specifications .specifications-content .specification {
        padding-left: 0 !important;
        margin-top: 10px;
        margin-bottom: 5px;

    }

    .product-specifications .specifications-content .specification-name {
        color: #1a425e;
        font-size: 16px;
        font-weight: 600;
    }

    .product-specifications .specifications-content .specification-value {
        color: #424242;
        font-size: 16px;
        font-weight: 500;
    }

    .no-specifications {
        text-align: center;
        padding: 14px;

        h2 : {
            color: #41b4be;
        }
    }

    .similar-products {
        background-color: #fff;
        height: 20%;
        height: fit-content;
        margin: 10px;
        box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.15);
    }

    .similar-products .products {
        display: flex !important;
    }

    .similar-products .products .owl-item {
        width: 250px !important;

    }

    .similar-products .title {
        font-size: 16px;
        font-weight: 600;
        font-stretch: normal;
        font-style: normal;
        line-height: 1.38;
        letter-spacing: 0.19px;
        color: #000000;
        padding: 10px;
    }

    /**Products*/
    .productBox {

        background-color: white;
        margin: 10px;
        height: fit-content;
        box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 0 1px 0 rgba(0, 0, 0, 0.4);
    }

    .productImage img {
        width: 100%;
        height: 155px;
    }

    .productName {
        padding: 2px;
        margin: 5px;
        height: 40px;
    }

    .productName a {
        color: #424242;
        font-size: 14px;
    }

    .productPriceContainer {
        height: 45px;
    }

    .productPrice {
        margin-left: 10px;
        color: #1a425e;
        height: 20px;
        font-family: Montserrat;
        font-weight: 600;
        bottom: 0;
    }

    .productPriceOffer {
        margin-left: 10px;
        color: #1a425e;
        height: 20px;
        font-family: Montserrat;
        font-weight: 600;

    }

    .productDescription {
        padding-left: 20px;
        color: #bdbdbd;
        max-height: 40px;
        overflow: hidden;
    }

    .addToCart {
        display: flex;
		margin: auto;
		width: 95%;
		background-color: #41b4be;
		height: 35px;
		align-items: center;
		justify-content: center;
		border-radius: 4px;
		cursor: pointer;
		margin: 5px;

    }

    .addToCart h4 {
        font-family: Montserrat;
        color: #fff;
        font-size: 14px;
    }

    .addToCartIcon {
        width: 20px !important;
        height: 20px;
        margin: 5px;
    }
</style>