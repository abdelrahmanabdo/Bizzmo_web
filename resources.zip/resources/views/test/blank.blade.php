@extends('layouts.app')
@section('title')

@stop
@section('styles')
	<style>

	</style>
@stop
@section('content')	

@stop
@push('scripts')	
	<script type="text/javascript">
		$(document).ready(function(){
			
		});
	</script>
@endpush