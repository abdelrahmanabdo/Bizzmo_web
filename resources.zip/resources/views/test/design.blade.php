
 <div class="Pending-POs">Pending POs</div>


<style>
.Pending-POs{
  width: 124px;
  height: 32px;
  font-family: Montserrat;
  font-size: 18px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.78;
  letter-spacing: 0.22px;
  color: #1a425e;
}

</style>