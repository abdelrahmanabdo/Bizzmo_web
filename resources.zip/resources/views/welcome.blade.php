@extends('layouts.app')

@section('title', 'Page Title')


@section('content')
    <div class="row">
		<div class="col-sm-6">
			<p>First</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
		</div>
		<div class="col-sm-6">
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
			<p>The big brown fox</p>
		</div>
	</div>
@endsection